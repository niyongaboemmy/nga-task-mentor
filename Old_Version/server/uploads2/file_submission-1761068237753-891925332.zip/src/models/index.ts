import { User } from "./User.model";
import { Course } from "./Course.model";
import { Assignment } from "./Assignment.model";
import { Submission } from "./Submission.model";
import { UserCourse } from "./UserCourse.model";

// Set up associations after all models are imported
const setupAssociations = () => {
  // ----------------------
  // User Associations
  // ----------------------
  User.hasMany(Assignment, {
    foreignKey: "created_by",
    as: "assignmentsCreated",
  });

  User.hasMany(Submission, {
    foreignKey: "student_id",
    as: "submissionsMade",
  });

  User.belongsToMany(Course, {
    through: UserCourse,
    foreignKey: "user_id",
    otherKey: "course_id",
    as: "enrolledCourses",
  });

  // ----------------------
  // Course Associations
  // ----------------------
  Course.belongsTo(User, {
    foreignKey: "instructor_id",
    as: "courseInstructor",
  });

  Course.hasMany(Assignment, {
    foreignKey: "course_id",
    as: "courseAssignments",
  });

  Course.belongsToMany(User, {
    through: UserCourse,
    foreignKey: "course_id",
    otherKey: "user_id",
    as: "studentsEnrolled",
  });

  // ----------------------
  // Assignment Associations
  // ----------------------
  Assignment.belongsTo(Course, {
    foreignKey: "course_id",
    as: "assignmentCourse",
  });

  Assignment.belongsTo(User, {
    foreignKey: "created_by",
    as: "assignmentCreator",
  });

  Assignment.hasMany(Submission, {
    foreignKey: "assignment_id",
    as: "assignmentSubmissions",
  });

  // ----------------------
  // Submission Associations
  // ----------------------
  Submission.belongsTo(Assignment, {
    foreignKey: "assignment_id",
    as: "submissionAssignment",
  });

  Submission.belongsTo(User, {
    foreignKey: "student_id",
    as: "submissionStudent",
  });

  // ----------------------
  // UserCourse Associations
  // ----------------------
  UserCourse.belongsTo(User, {
    foreignKey: "user_id",
    as: "userInCourse",
  });

  UserCourse.belongsTo(Course, {
    foreignKey: "course_id",
    as: "courseInUserCourse",
  });

  // Add reverse associations for complete relationship
  User.hasMany(UserCourse, {
    foreignKey: "user_id",
    as: "userCourses",
  });

  Course.hasMany(UserCourse, {
    foreignKey: "course_id",
    as: "courseUserCourses",
  });
};

export * from "./User.model";
export * from "./Course.model";
export * from "./Assignment.model";
export * from "./Submission.model";
export * from "./UserCourse.model";

export { User, Course, Assignment, Submission, UserCourse, setupAssociations };

export default { User, Course, Assignment, Submission, UserCourse, setupAssociations };
