import { Router } from "express";
import {
  getAssignments,
  getAssignment,
  createAssignment,
  updateAssignment,
  updateAssignmentStatus,
  deleteAssignment,
  publishAssignment,
  getAssignmentSubmissions,
  getEnrolledAssignments,
  submitAssignment,
} from "../controllers/assignment.controller";
import { protect, authorize, isCourseInstructor } from "../middleware/auth";

// Configure multer for file uploads (same config as in index.ts)
import multer from "multer";
import path from "path";
import fs from "fs";

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, "../../uploads");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Accept common file types for assignments
    const allowedTypes = [
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/zip",
      "text/plain",
      "image/jpeg",
      "image/png",
      "image/gif",
    ];

    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only PDF, DOC, XLS, ZIP, TXT, and images are allowed."));
    }
  },
});

const router = Router();

// Public routes
router.get("/", getAssignments);
// Get enrolled assignments for students
router.get(
  "/enrolled",
  protect,
  authorize("student"),
  getEnrolledAssignments
);
router.get("/:id", getAssignment);

// Protected routes
router.use(protect);

// Instructor and admin routes - these should be for general assignment operations
router.post("/", authorize("instructor", "admin"), createAssignment);

// Course instructor and admin routes
router
  .route("/:id")
  .put(authorize("instructor", "admin"), isCourseInstructor, updateAssignment)
  .delete(
    authorize("instructor", "admin"),
    isCourseInstructor,
    deleteAssignment
  );

// Publish assignment (legacy route - keeping for backward compatibility)
router.put(
  "/:id/publish",
  authorize("instructor", "admin"),
  isCourseInstructor,
  publishAssignment
);

// Update assignment status
router.patch(
  "/:id/status",
  authorize("instructor", "admin"),
  isCourseInstructor,
  updateAssignmentStatus
);

// Submit assignment (for students) - temporarily remove auth for testing
router.post(
  "/:id/submit",
  upload.single("file_submission"), // Apply multer middleware for file uploads
  protect,
  authorize("student"),
  submitAssignment
);

// Get submissions for an assignment
router.get(
  "/:id/submissions",
  protect,
  // authorize("instructor", "admin"), // Allow all authenticated users to view submissions
  getAssignmentSubmissions
);

// Download submissions as zip (TODO: implement)
// router.get(
//   "/:id/submissions/download",
//   authorize("instructor", "admin"),
//   isCourseInstructor,
//   downloadSubmissions
// );

export default router;
