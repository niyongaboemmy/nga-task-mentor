import { Request, Response } from "express";
import { Op, Sequelize } from "sequelize";
import { User } from "../models/User.model";
import { Course } from "../models/Course.model";
import { Assignment } from "../models/Assignment.model";
import { Submission } from "../models/Submission.model";
import { UserCourse } from "../models/UserCourse.model";

// Interface for dashboard statistics
interface DashboardStats {
  totalCourses: number;
  totalAssignments: number;
  pendingSubmissions: number;
  completedAssignments: number;
  totalEnrolledStudents?: number; // For instructors only
}

// Interface for recent activity
interface RecentActivity {
  id: string;
  type: "assignment" | "submission" | "course";
  title: string;
  description: string;
  timestamp: string;
}

// Student Dashboard Statistics
export const getStudentStats = async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;

    // Get user's enrolled courses
    const enrolledCourses = await UserCourse.findAll({
      where: { user_id: userId },
      attributes: ['course_id']
    });

    const courseIds = enrolledCourses.map(ec => ec.course_id);

    if (courseIds.length === 0) {
      // No enrolled courses, return zeros
      const stats: DashboardStats = {
        totalCourses: 0,
        totalAssignments: 0,
        pendingSubmissions: 0,
        completedAssignments: 0
      };

      return res.status(200).json({
        success: true,
        data: stats
      });
    }

    // Get total assignments from enrolled courses that are published
    const totalAssignments = await Assignment.count({
      where: {
        course_id: { [Op.in]: courseIds },
        status: "published"
      }
    });

    // Get user's submissions for assignments in enrolled courses
    const userSubmissions = await Submission.findAll({
      include: [
        {
          model: Assignment,
          as: "assignment",
          where: {
            course_id: { [Op.in]: courseIds }
          },
          required: true
        }
      ],
      where: { student_id: userId }
    });

    // Count completed assignments (assignments with submissions)
    const completedAssignments = userSubmissions.length;

    // Count pending assignments (published assignments in enrolled courses without submissions)
    const pendingSubmissions = await Assignment.count({
      where: {
        course_id: { [Op.in]: courseIds },
        status: "published",
        id: {
          [Op.notIn]: userSubmissions.map(s => s.assignment_id)
        }
      }
    });

    const stats: DashboardStats = {
      totalCourses: courseIds.length,
      totalAssignments,
      pendingSubmissions,
      completedAssignments
    };

    res.status(200).json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error("Error fetching student stats:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching dashboard statistics"
    });
  }
};

// Student Pending Assignments
export const getStudentPendingAssignments = async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;

    // Get user's enrolled courses
    const enrolledCourses = await UserCourse.findAll({
      where: { user_id: userId },
      attributes: ['course_id']
    });

    const courseIds = enrolledCourses.map(ec => ec.course_id);

    if (courseIds.length === 0) {
      // No enrolled courses, return empty array
      return res.status(200).json({
        success: true,
        data: []
      });
    }

    // Get user's existing submissions for assignments in enrolled courses
    const userSubmissions = await Submission.findAll({
      where: { student_id: userId },
      attributes: ['assignment_id']
    });

    const submittedAssignmentIds = userSubmissions.map(s => s.assignment_id);

    // Get pending assignments (published assignments in enrolled courses without submissions)
    const pendingAssignments = await Assignment.findAll({
      include: [
        {
          model: Course,
          as: "course",
          attributes: ["id", "title", "code"],
          required: true
        },
        {
          model: User,
          as: "creator",
          attributes: ["id", "first_name", "last_name"]
        }
      ],
      where: {
        course_id: { [Op.in]: courseIds },
        status: "published",
        id: {
          [Op.notIn]: submittedAssignmentIds
        },
        due_date: {
          [Op.gt]: new Date() // Not overdue
        }
      },
      order: [["due_date", "ASC"]]
    });

    // Format the data to match frontend expectations
    const formattedAssignments = pendingAssignments.map(assignment => ({
      id: assignment.id.toString(),
      title: assignment.title,
      description: assignment.description,
      due_date: assignment.due_date.toISOString(),
      max_score: assignment.max_score.toString(),
      submission_type: assignment.submission_type,
      allowed_file_types: assignment.allowed_file_types || "",
      rubric: assignment.rubric || "",
      course_id: assignment.course_id.toString(),
      created_by: assignment.created_by?.toString() || "",
      createdAt: assignment.createdAt.toISOString(),
      updatedAt: assignment.updatedAt.toISOString(),
      creator: assignment.creator ? {
        id: assignment.creator.id.toString(),
        first_name: assignment.creator.first_name,
        last_name: assignment.creator.last_name
      } : undefined,
      course: assignment.course ? {
        id: assignment.course.id.toString(),
        title: assignment.course.title,
        code: assignment.course.code
      } : undefined,
      submissions: [], // No submissions since these are pending
      isPublished: assignment.status === "published",
      status: assignment.status
    }));

    res.status(200).json({
      success: true,
      data: formattedAssignments
    });
  } catch (error) {
    console.error("Error fetching pending assignments:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching pending assignments"
    });
  }
};

// Instructor Dashboard Statistics
export const getInstructorStats = async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;

    // Get courses taught by instructor
    const totalCourses = await Course.count({
      where: { instructor_id: userId }
    });

    // Get assignments created by instructor
    const totalAssignments = await Assignment.count({
      where: { created_by: userId }
    });

    // Get pending submissions (assignments with submissions that haven't been graded)
    const pendingSubmissions = await Submission.count({
      include: [
        {
          model: Assignment,
          as: "assignment",
          where: { created_by: userId },
          required: true
        }
      ],
      where: {
        status: {
          [Op.ne]: "graded"
        }
      }
    });

    // Get completed assignments (graded submissions)
    const completedAssignments = await Submission.count({
      include: [
        {
          model: Assignment,
          as: "assignment",
          where: { created_by: userId },
          required: true
        }
      ],
      where: {
        status: "graded"
      }
    });

    // Get total enrolled students across all courses taught by instructor
    const enrolledStudents = await UserCourse.count({
      include: [
        {
          model: Course,
          as: "courseInUserCourse",
          where: { instructor_id: userId },
          required: true
        }
      ],
      where: { status: "enrolled" }
    });

    const stats: DashboardStats = {
      totalCourses,
      totalAssignments,
      pendingSubmissions,
      completedAssignments,
      totalEnrolledStudents: enrolledStudents
    };

    res.status(200).json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error("Error fetching instructor stats:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching dashboard statistics"
    });
  }
};

// Instructor Courses Overview
export const getInstructorCourses = async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;

    // First, let's try a simpler query to see if basic course retrieval works
    const courses = await Course.findAll({
      where: { instructor_id: userId },
      attributes: [
        "id",
        "code",
        "title",
        "description",
        "credits",
        "is_active",
        "max_students",
        "start_date",
        "end_date"
      ],
      order: [["createdAt", "DESC"]],
      limit: 6
    });

    // Format the data for frontend
    const formattedCourses = courses.map(course => ({
      id: course.id.toString(),
      code: course.code,
      title: course.title,
      description: course.description,
      credits: course.credits,
      is_active: course.is_active,
      max_students: course.max_students,
      start_date: new Date(course.start_date).toISOString(),
      end_date: new Date(course.end_date).toISOString(),
      assignmentCount: 0, // Will be calculated separately
      enrolledCount: 0, // Will be calculated separately
      progress: {
        enrolled: 0,
        capacity: course.max_students,
        assignments: 0
      }
    }));

    res.status(200).json({
      success: true,
      data: formattedCourses
    });
  } catch (error) {
    console.error("Error fetching instructor courses:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching courses overview",
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Instructor Pending Grading Assignments
export const getInstructorPendingGrading = async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;

    // Get assignments created by instructor that have ungraded submissions
    const pendingGrading = await Assignment.findAll({
      include: [
        {
          model: Course,
          as: "course",
          attributes: ["id", "title", "code"],
          where: { instructor_id: userId },
          required: true
        },
        {
          model: Submission,
          as: "submissions",
          where: {
            status: {
              [Op.ne]: "graded"
            }
          },
          required: true,
          attributes: ["id", "status", "submitted_at", "student_id"],
          include: [
            {
              model: User,
              as: "student",
              attributes: ["id", "first_name", "last_name"]
            }
          ]
        }
      ],
      where: {
        created_by: userId,
        status: "published"
      },
      order: [["due_date", "ASC"]]
    });

    // Format the data for frontend
    const formattedAssignments = pendingGrading.map(assignment => ({
      id: assignment.id.toString(),
      title: assignment.title,
      description: assignment.description,
      due_date: assignment.due_date.toISOString(),
      max_score: assignment.max_score.toString(),
      submission_type: assignment.submission_type,
      pendingSubmissions: assignment.submissions?.length || 0,
      course: assignment.course ? {
        id: assignment.course.id.toString(),
        title: assignment.course.title,
        code: assignment.course.code
      } : undefined,
      submissions: assignment.submissions?.map((submission: any) => ({
        id: submission.id.toString(),
        status: submission.status,
        submitted_at: submission.submitted_at.toISOString(),
        student: submission.student ? {
          id: submission.student.id.toString(),
          first_name: submission.student.first_name,
          last_name: submission.student.last_name
        } : undefined
      })) || []
    }));

    res.status(200).json({
      success: true,
      data: formattedAssignments
    });
  } catch (error) {
    console.error("Error fetching pending grading:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching pending grading assignments"
    });
  }
};

// Admin Dashboard Statistics
export const getAdminStats = async (req: Request, res: Response) => {
  try {
    // Get total courses in the system
    const totalCourses = await Course.count();

    // Get total assignments in the system
    const totalAssignments = await Assignment.count();

    // Get pending submissions (all ungraded submissions)
    const pendingSubmissions = await Submission.count({
      where: {
        status: {
          [Op.ne]: "graded"
        }
      }
    });

    // Get completed assignments (all graded submissions)
    const completedAssignments = await Submission.count({
      where: {
        status: "graded"
      }
    });

    const stats: DashboardStats = {
      totalCourses,
      totalAssignments,
      pendingSubmissions,
      completedAssignments
    };

    res.status(200).json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error("Error fetching admin stats:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching dashboard statistics"
    });
  }
};

// Recent Activity (for logged-in user only)
export const getRecentActivity = async (req: Request, res: Response) => {
  try {
    const userId = req.user.id;
    const userRole = req.user.role;
    const activities: RecentActivity[] = [];

    if (userRole === "student") {
      // Get recent submissions by the user
      const recentSubmissions = await Submission.findAll({
        include: [
          {
            model: Assignment,
            as: "assignment",
            attributes: ["id", "title"]
          }
        ],
        where: { student_id: userId },
        order: [["createdAt", "DESC"]],
        limit: 10
      });

      recentSubmissions.forEach(submission => {
        activities.push({
          id: `submission_${submission.id}`,
          type: "submission",
          title: submission.assignment.title,
          description: `You submitted an assignment: ${submission.assignment.title}`,
          timestamp: submission.createdAt.toISOString()
        });
      });
    } else if (userRole === "instructor") {
      // Get recent submissions that need grading (for instructor's assignments)
      const recentSubmissions = await Submission.findAll({
        include: [
          {
            model: Assignment,
            as: "assignment",
            attributes: ["id", "title"],
            where: { created_by: userId },
            include: [
              {
                model: User,
                as: "creator",
                attributes: ["id", "first_name", "last_name"]
              }
            ]
          },
          {
            model: User,
            as: "student",
            attributes: ["id", "first_name", "last_name"]
          }
        ],
        where: {
          status: {
            [Op.ne]: "graded"
          }
        },
        order: [["createdAt", "DESC"]],
        limit: 5
      });

      recentSubmissions.forEach(submission => {
        activities.push({
          id: `submission_${submission.id}`,
          type: "submission",
          title: submission.assignment.title,
          description: `${submission.student.first_name} ${submission.student.last_name} submitted: ${submission.assignment.title}`,
          timestamp: submission.createdAt.toISOString()
        });
      });

      // Get recently created assignments by the instructor
      const recentAssignments = await Assignment.findAll({
        include: [
          {
            model: Course,
            as: "course",
            attributes: ["id", "title", "code"]
          }
        ],
        where: { created_by: userId },
        order: [["createdAt", "DESC"]],
        limit: 5
      });

      recentAssignments.forEach(assignment => {
        activities.push({
          id: `assignment_${assignment.id}`,
          type: "assignment",
          title: assignment.title,
          description: `You created assignment: ${assignment.title} for ${assignment.course.title}`,
          timestamp: assignment.createdAt.toISOString()
        });
      });

      // Get recent student enrollments in instructor's courses
      const recentEnrollments = await UserCourse.findAll({
        include: [
          {
            model: Course,
            as: "courseInUserCourse",
            attributes: ["id", "title", "code"],
            where: { instructor_id: userId },
            required: true
          },
          {
            model: User,
            as: "userInCourse",
            attributes: ["id", "first_name", "last_name"]
          }
        ],
        where: { status: "enrolled" },
        order: [["createdAt", "DESC"]],
        limit: 5
      });

      recentEnrollments.forEach(enrollment => {
        activities.push({
          id: `enrollment_${enrollment.id}`,
          type: "course",
          title: (enrollment as any).courseInUserCourse.title,
          description: `${(enrollment as any).userInCourse.first_name} ${(enrollment as any).userInCourse.last_name} enrolled in ${(enrollment as any).courseInUserCourse.title}`,
          timestamp: enrollment.createdAt.toISOString()
        });
      });
    }

    // Sort all activities by timestamp
    activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    const recentActivities = activities.slice(0, 15);

    res.status(200).json({
      success: true,
      data: recentActivities
    });
  } catch (error) {
    console.error("Error fetching recent activity:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching recent activity"
    });
  }
};
