import { Request, Response } from "express";
import { Assignment, Course, Submission, User, UserCourse } from "../models";

// @desc    Get all assignments
// @route   GET /api/assignments
// @access  Public
export const getAssignments = async (req: Request, res: Response) => {
  try {
    const assignments = await Assignment.findAll({
      include: [
        {
          model: Course,
          attributes: ["id", "title", "code"],
        },
      ],
    });
    res
      .status(200)
      .json({ success: true, count: assignments.length, data: assignments });
  } catch (error) {
    console.error("Get assignments error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Get single assignment
// @route   GET /api/assignments/:id
// @access  Public
export const getAssignment = async (req: Request, res: Response) => {
  try {
    const assignment = await Assignment.findByPk(req.params.id, {
      include: [
        {
          model: Course,
          attributes: ["id", "title", "code"],
        },
      ],
    });

    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    res.status(200).json({ success: true, data: assignment });
  } catch (error) {
    console.error("Get assignment error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Create assignment
// @route   POST /api/courses/:courseId/assignments
// @access  Private/Instructor/Admin
export const createAssignment = async (req: Request, res: Response) => {
  try {
    const {
      title,
      description,
      due_date,
      max_score,
      submission_type = "both",
    } = req.body;
    const { courseId } = req.params;

    const assignment = await Assignment.create({
      title,
      description,
      due_date,
      max_score,
      course_id: parseInt(courseId),
      submission_type,
      created_by: req.user.id,
    });

    res.status(201).json({ success: true, data: assignment });
  } catch (error) {
    console.error("Create assignment error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Update assignment
// @route   PUT /api/assignments/:id
// @access  Private/Instructor/Admin (must be course instructor)
export const updateAssignment = async (req: Request, res: Response) => {
  try {
    const {
      title,
      description,
      due_date,
      max_score,
      submission_type,
      allowed_file_types,
      rubric,
      status
    } = req.body;

    const assignment = await Assignment.findByPk(req.params.id);

    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    // Update fields if provided
    if (title !== undefined) assignment.title = title;
    if (description !== undefined) assignment.description = description;
    if (due_date !== undefined) assignment.due_date = due_date;
    if (max_score !== undefined) assignment.max_score = max_score;
    if (submission_type !== undefined) assignment.submission_type = submission_type;
    if (allowed_file_types !== undefined) assignment.allowed_file_types = allowed_file_types;
    if (rubric !== undefined) assignment.rubric = rubric;
    if (status !== undefined) {
      const validStatuses = ["draft", "published", "completed", "removed"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: `Invalid status. Must be one of: ${validStatuses.join(", ")}`,
        });
      }
      assignment.status = status;
    }

    await assignment.save();

    // Fetch updated assignment with course info
    const updatedAssignment = await Assignment.findByPk(req.params.id, {
      include: [
        {
          model: Course,
          attributes: ["id", "title", "code"],
        },
      ],
    });

    res.status(200).json({ success: true, data: updatedAssignment });
  } catch (error) {
    console.error("Update assignment error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Delete assignment
// @route   DELETE /api/assignments/:id
// @access  Private/Instructor/Admin
export const deleteAssignment = async (req: Request, res: Response) => {
  try {
    const assignment = await Assignment.findByPk(req.params.id);

    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    await assignment.destroy();

    res.status(200).json({ success: true, data: {} });
  } catch (error) {
    console.error("Delete assignment error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Publish assignment
// @route   PUT /api/assignments/:id/publish
// @access  Private/Instructor/Admin
export const publishAssignment = async (req: Request, res: Response) => {
  try {
    const assignment = await Assignment.findByPk(req.params.id);

    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    // Assignment is already published by default, just return success
    res.status(200).json({ success: true, data: assignment });
  } catch (error) {
    console.error("Publish assignment error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Get assignment submissions
// @route   GET /api/assignments/:id/submissions
// @access  Private/Instructor/Admin
export const getAssignmentSubmissions = async (req: Request, res: Response) => {
  try {
    const assignment = await Assignment.findByPk(req.params.id, {
      include: [
        {
          model: Submission,
          include: [
            {
              model: User,
              attributes: ["id", "first_name", "last_name", "email"],
            },
          ],
        },
      ],
    });

    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    res.status(200).json({
      success: true,
      count: assignment.submissions.length,
      data: assignment.submissions,
    });
  } catch (error) {
    console.error("Get assignment submissions error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Get enrolled assignments for student
// @route   GET /api/assignments/enrolled
// @access  Private/Student
export const getEnrolledAssignments = async (req: Request, res: Response) => {
  try {
    // Check if user is authenticated and is a student
    if (!req.user) {
      return res
        .status(401)
        .json({ success: false, message: "Not authenticated" });
    }

    if (req.user.role !== "student") {
      return res
        .status(403)
        .json({ success: false, message: "Access denied. Students only." });
    }

    const studentId = req.user.id;
    console.log("Student ID from token:", studentId);
    console.log("Student role:", req.user.role);

    // Find courses where the student is enrolled using UserCourse directly
    const { UserCourse } = await import("../models");
    const enrollments = await UserCourse.findAll({
      where: { user_id: studentId, status: "enrolled" },
      attributes: ["course_id"],
    });

    console.log("Found enrollments:", enrollments.length);

    if (enrollments.length === 0) {
      console.log("No enrollments found for student:", studentId);
      return res.status(200).json({ success: true, count: 0, data: [] });
    }

    const courseIds = enrollments.map((enrollment) => enrollment.course_id);
    console.log("Course IDs:", courseIds);

    // Get only published assignments from enrolled courses
    const assignments = await Assignment.findAll({
      where: {
        course_id: courseIds,
        status: "published",
      },
      include: [
        {
          model: Course,
          attributes: ["id", "title", "code"],
        },
      ],
      order: [["due_date", "ASC"]],
    });

    console.log("Found assignments:", assignments.length);

    res.status(200).json({
      success: true,
      count: assignments.length,
      data: assignments,
    });
  } catch (error) {
    console.error("Get enrolled assignments error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Update assignment status
// @route   PATCH /api/assignments/:id/status
// @access  Private/Instructor/Admin
export const updateAssignmentStatus = async (req: Request, res: Response) => {
  try {
    const { status } = req.body;
    const { id } = req.params;

    // Validate status
    const validStatuses = ["draft", "published", "completed", "removed"];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Must be one of: ${validStatuses.join(", ")}`,
      });
    }

    const assignment = await Assignment.findByPk(id);

    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    // Update the status
    assignment.status = status;
    await assignment.save();

    res.status(200).json({ success: true, data: assignment });
  } catch (error) {
    console.error("Update assignment status error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};
// @desc    Submit assignment
// @route   POST /api/assignments/:id/submit
// @access  Private/Student
export const submitAssignment = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // 1. Check if user is authenticated and is a student
    if (!req.user) {
      return res
        .status(401)
        .json({ success: false, message: "Authentication required" });
    }

    if (req.user.role !== "student") {
      return res
        .status(403)
        .json({ success: false, message: "Only students can submit assignments" });
    }

    // 2. Check if assignment exists
    const assignment = await Assignment.findByPk(id);
    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    // 3. Check if assignment is published
    if (assignment.status !== "published") {
      return res.status(400).json({
        success: false,
        message: "Assignment is not published. Cannot submit.",
      });
    }

    // 4. Check if student is enrolled in the course
    const { UserCourse } = await import("../models");
    const enrollment = await UserCourse.findOne({
      where: {
        user_id: req.user.id,
        course_id: assignment.course_id,
        status: "enrolled"
      }
    });

    if (!enrollment) {
      return res.status(403).json({
        success: false,
        message: "You are not enrolled in this course. Cannot submit assignment.",
      });
    }

    // Helper function for Kigali timezone conversion
    const getKigaliTime = (date: Date) => {
      const kigaliOffset = 2 * 60; // UTC+2 in minutes
      return new Date(date.getTime() + (kigaliOffset * 60 * 1000));
    };

    // 5. Check if assignment is still open for submissions (Kigali timezone UTC+2)
    const now = new Date();
    const nowKigali = getKigaliTime(now);

    const dueDate = new Date(assignment.due_date);
    const dueDateKigali = getKigaliTime(dueDate);

    if (nowKigali > dueDateKigali) {
      return res.status(400).json({
        success: false,
        message:
          "Assignment deadline has passed. Submissions are no longer accepted.",
      });
    }

    // 6. Check if student has already submitted
    const existingSubmission = await Submission.findOne({
      where: {
        assignment_id: id,
        student_id: req.user.id
      }
    });

    if (existingSubmission) {
      return res.status(400).json({
        success: false,
        message: 'You have already submitted this assignment. Multiple submissions are not allowed.'
      });
    }

    // 7. Validate submission content
    const text_submission = req.body.text_submission;
    const file_submission = (req as any).file?.path;

    console.log("Submission validation:", {
      text_submission,
      file_submission,
      hasText: !!text_submission,
      hasFile: !!file_submission,
      reqFile: (req as any).file,
      reqBody: req.body
    });

    if (!text_submission && !file_submission) {
      return res.status(400).json({
        success: false,
        message: "Please provide either text submission or file submission.",
      });
    }

    // Create submission
    const submission = await Submission.create({
      assignment_id: parseInt(id),
      student_id: req.user.id,
      text_submission: text_submission || null,
      file_submissions: file_submission
        ? [
            {
              filename: (req as any).file?.originalname || file_submission.split("/").pop() || "submission",
              originalname: (req as any).file?.originalname || file_submission.split("/").pop() || "submission",
              path: file_submission,
              size: (req as any).file?.size || 0,
              mimetype: (req as any).file?.mimetype || "application/octet-stream",
            },
          ]
        : null,
      status: "submitted",
      submitted_at: new Date(),
      is_late: nowKigali > dueDateKigali,
    });

    res.status(201).json({
      success: true,
      message: "Assignment submitted successfully",
      data: submission,
    });
  } catch (error) {
    console.error("Submit assignment error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// @desc    Delete student's own submission
// @route   DELETE /api/submissions/:id
// @access  Private/Student (own submission only)
export const deleteSubmission = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    // Check if submission exists and belongs to the authenticated student
    const submission = await Submission.findByPk(id);

    if (!submission) {
      return res
        .status(404)
        .json({ success: false, message: "Submission not found" });
    }

    // Ensure only the student who submitted can delete their own submission
    if (submission.student_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: "You can only delete your own submissions",
      });
    }

    // Check if assignment is still open for submissions
    const assignment = await Assignment.findByPk(submission.assignment_id);
    if (!assignment) {
      return res
        .status(404)
        .json({ success: false, message: "Assignment not found" });
    }

    // Helper function for Kigali timezone conversion
    const getKigaliTime = (date: Date) => {
      const kigaliOffset = 2 * 60; // UTC+2 in minutes
      return new Date(date.getTime() + (kigaliOffset * 60 * 1000));
    };

    const now = new Date();
    const nowKigali = getKigaliTime(now);
    const dueDate = new Date(assignment.due_date);
    const dueDateKigali = getKigaliTime(dueDate);

    if (nowKigali > dueDateKigali) {
      return res.status(400).json({
        success: false,
        message: "Cannot delete submission after the due date",
      });
    }

    // Delete the submission
    await submission.destroy();

    res.status(200).json({
      success: true,
      message: "Submission deleted successfully",
      data: {},
    });
  } catch (error) {
    console.error("Delete submission error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};
